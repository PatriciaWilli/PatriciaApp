# Installation & Setup Guide

## 📋 Voraussetzungen

Bevor Sie beginnen, stellen Sie sicher, dass Sie folgendes installiert haben:

- **Node.js** (Version 16 oder höher)
  - Download: https://nodejs.org/
  - Überprüfen: `node --version`
- **npm** (kommt mit Node.js) oder **yarn**
  - Überprüfen: `npm --version`

## 🚀 Schnellstart

### 1. Repository klonen oder ZIP entpacken

```bash
# Mit Git
git clone https://github.com/[IhrUsername]/event-manager-app.git
cd event-manager-app

# Oder ZIP-Datei entpacken und in den Ordner wechseln
cd event-manager-app
```

### 2. Abhängigkeiten installieren

```bash
npm install
```

Dies installiert alle erforderlichen Pakete:
- React & React-DOM
- Tailwind CSS
- Lucide React (Icons)
- React Scripts

⏱️ **Dauer:** 1-3 Minuten (je nach Internetverbindung)

### 3. Entwicklungsserver starten

```bash
npm start
```

Die App öffnet sich automatisch im Browser unter:
```
http://localhost:3000
```

## 🎯 Erste Schritte

### Login mit Test-Accounts

**Benutzer-Account:**
- Email: `max@example.com`
- Passwort: `pass123`

**Admin-Account:**
- Email: `admin@example.com`
- Passwort: `admin123`

## 🛠️ Verfügbare Kommandos

| Kommando | Beschreibung |
|----------|--------------|
| `npm start` | Startet den Entwicklungsserver |
| `npm run build` | Erstellt optimierte Production-Version |
| `npm test` | Führt Tests aus |
| `npm run eject` | Erweiterte Konfiguration (nicht rückgängig!) |

## 📦 Production Build

Für die Veröffentlichung der App:

```bash
npm run build
```

Dies erstellt einen `build/` Ordner mit optimierten Dateien.

## 🌐 Deployment

### Option 1: Vercel (empfohlen)

1. Account erstellen: https://vercel.com
2. GitHub Repository verbinden
3. Automatisches Deployment bei jedem Push

```bash
# Mit Vercel CLI
npm install -g vercel
vercel deploy
```

### Option 2: Netlify

1. Account erstellen: https://netlify.com
2. Drag & Drop des `build/` Ordners
3. Fertig!

### Option 3: GitHub Pages

1. In `package.json` hinzufügen:
```json
"homepage": "https://[username].github.io/event-manager-app"
```

2. Installieren:
```bash
npm install gh-pages --save-dev
```

3. Scripts hinzufügen:
```json
"predeploy": "npm run build",
"deploy": "gh-pages -d build"
```

4. Deployen:
```bash
npm run deploy
```

## 🔧 Fehlerbehebung

### Problem: "npm: command not found"
**Lösung:** Node.js installieren von https://nodejs.org/

### Problem: Port 3000 bereits belegt
**Lösung:** 
```bash
# Anderen Port verwenden
PORT=3001 npm start
```

### Problem: Module nicht gefunden
**Lösung:**
```bash
# Node modules löschen und neu installieren
rm -rf node_modules package-lock.json
npm install
```

### Problem: Build-Fehler
**Lösung:**
```bash
# Cache leeren
npm cache clean --force
npm install
```

## 📱 Mobile App (Optional)

Für eine native Mobile App mit React Native:

1. **Expo** verwenden:
```bash
npx expo init event-manager-mobile
```

2. Komponenten aus `src/App.jsx` übernehmen
3. React Native spezifische Komponenten verwenden

## 🔐 Sicherheitshinweise

⚠️ **Wichtig für Production:**

1. **Passwörter verschlüsseln:** Aktuell sind Passwörter im Frontend gespeichert
2. **Backend einrichten:** Node.js/Express + MongoDB/PostgreSQL
3. **Authentifizierung:** JWT Tokens verwenden
4. **HTTPS:** SSL-Zertifikat verwenden

### Empfohlener Backend-Stack:
- **Backend:** Node.js + Express
- **Datenbank:** MongoDB oder PostgreSQL
- **Auth:** JWT + bcrypt
- **API:** RESTful oder GraphQL

## 📊 Datenbank-Schema (für Backend)

```javascript
// User Model
{
  id: String,
  nickname: String,
  email: String,
  password: String (hashed),
  isActive: Boolean,
  isAdmin: Boolean,
  createdAt: Date
}

// Event Model
{
  id: String,
  title: String,
  date: Date,
  timeFrom: String,
  timeTo: String,
  location: String,
  createdBy: String (userId),
  createdAt: Date
}

// Response Model
{
  id: String,
  eventId: String,
  userId: String,
  response: String (yes/no),
  utensilResponses: Object,
  createdAt: Date
}
```

## 🎨 Anpassungen

### Design ändern
Farben in `tailwind.config.js` anpassen oder in `src/App.jsx` die Tailwind-Klassen ändern.

### Neue Features
1. Komponenten in `src/components/` erstellen
2. In `src/App.jsx` importieren
3. State Management mit Context API oder Redux erweitern

## 📧 Support

Bei Fragen:
1. Issue auf GitHub erstellen
2. README.md durchlesen
3. Code-Kommentare prüfen

## 🎉 Fertig!

Ihre App läuft jetzt lokal. Viel Erfolg mit dem Event Manager!
