import React, { useState } from 'react';
import { Calendar, MapPin, Clock, Users, CheckCircle, XCircle, UserPlus, Settings, LogOut, Plus, Trash2, Edit } from 'lucide-react';

const EventManagerApp = () => {
  // Authentifizierung
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Daten
  const [players] = useState([
    { id: 1, nickname: 'Max', email: 'max@example.com', password: 'pass123', isActive: true, isAdmin: false },
    { id: 2, nickname: 'Anna', email: 'anna@example.com', password: 'pass123', isActive: true, isAdmin: false },
    { id: 3, nickname: 'Tom', email: 'tom@example.com', password: 'pass123', isActive: true, isAdmin: false },
    { id: 4, nickname: 'Lisa', email: 'lisa@example.com', password: 'pass123', isActive: false, isAdmin: false },
    { id: 5, nickname: 'Admin', email: 'admin@example.com', password: 'admin123', isActive: true, isAdmin: true }
  ]);

  const [events, setEvents] = useState([
    {
      id: 1,
      title: 'Fussball Training',
      date: '2025-11-05',
      timeFrom: '18:00',
      timeTo: '20:00',
      location: 'Sportplatz Mitte',
      responses: { 1: 'yes', 2: 'yes', 3: 'no' },
      guests: [],
      comments: []
    },
    {
      id: 2,
      title: 'Turnier Vorbereitung',
      date: '2025-11-12',
      timeFrom: '17:00',
      timeTo: '19:00',
      location: 'Sporthalle Nord',
      responses: { 1: 'yes' },
      guests: [],
      comments: []
    }
  ]);

  const [utensils] = useState([
    { id: 1, name: 'Ball', icon: '⚽' },
    { id: 2, name: 'Pumpe', icon: '🔧' },
    { id: 3, name: 'Überzieher', icon: '👕' }
  ]);

  const [utensilResponses, setUtensilResponses] = useState({});
  const [showAdminView, setShowAdminView] = useState(false);
  const [newEvent, setNewEvent] = useState({
    title: '',
    date: '',
    timeFrom: '',
    timeTo: '',
    location: ''
  });
  const [newGuest, setNewGuest] = useState({});
  const [newComment, setNewComment] = useState({});
  const [playersStatus, setPlayersStatus] = useState(
    players.reduce((acc, p) => ({ ...acc, [p.id]: p.isActive }), {})
  );

  // Login Handler
  const handleLogin = (e) => {
    e.preventDefault();
    const user = players.find(p => p.email === loginEmail && p.password === loginPassword);
    if (user && user.isActive) {
      setCurrentUser(user);
      setIsLoggedIn(true);
      setShowAdminView(user.isAdmin);
    } else {
      alert('Login fehlgeschlagen! Bitte überprüfen Sie Ihre Anmeldedaten.');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    setLoginEmail('');
    setLoginPassword('');
    setShowAdminView(false);
  };

  // Event Response Handler
  const handleResponse = (eventId, response) => {
    setEvents(events.map(event => 
      event.id === eventId
        ? { ...event, responses: { ...event.responses, [currentUser.id]: response } }
        : event
    ));
  };

  // Utensil Response Handler
  const handleUtensilResponse = (eventId, utensilId, willBring) => {
    const key = `${eventId}-${utensilId}`;
    setUtensilResponses({
      ...utensilResponses,
      [key]: willBring ? currentUser.id : null
    });
  };

  // Guest Handler
  const handleAddGuest = (eventId) => {
    if (!newGuest[eventId]) return;
    setEvents(events.map(event =>
      event.id === eventId
        ? { ...event, guests: [...(event.guests || []), { name: newGuest[eventId], addedBy: currentUser.nickname }] }
        : event
    ));
    setNewGuest({ ...newGuest, [eventId]: '' });
  };

  // Comment Handler
  const handleAddComment = (eventId) => {
    if (!newComment[eventId]) return;
    setEvents(events.map(event =>
      event.id === eventId
        ? { 
            ...event, 
            comments: [...(event.comments || []), { 
              text: newComment[eventId], 
              author: currentUser.nickname,
              timestamp: new Date().toLocaleString('de-DE')
            }] 
          }
        : event
    ));
    setNewComment({ ...newComment, [eventId]: '' });
  };

  // Admin: Create Event
  const handleCreateEvent = (e) => {
    e.preventDefault();
    const event = {
      id: events.length + 1,
      ...newEvent,
      responses: {},
      guests: [],
      comments: []
    };
    setEvents([...events, event]);
    setNewEvent({ title: '', date: '', timeFrom: '', timeTo: '', location: '' });
  };

  // Admin: Toggle Player Status
  const togglePlayerStatus = (playerId) => {
    setPlayersStatus({
      ...playersStatus,
      [playerId]: !playersStatus[playerId]
    });
  };

  // Admin: Delete Event
  const handleDeleteEvent = (eventId) => {
    if (window.confirm('Event wirklich löschen?')) {
      setEvents(events.filter(e => e.id !== eventId));
    }
  };

  // Count participants
  const countParticipants = (event) => {
    return Object.values(event.responses).filter(r => r === 'yes').length;
  };

  // Login Screen
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-indigo-600 rounded-full mb-4">
              <Calendar className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-800">Event Manager</h1>
            <p className="text-gray-600 mt-2">Willkommen zurück!</p>
          </div>
          
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <input
                type="email"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                placeholder="deine@email.com"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Passwort</label>
              <input
                type="password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                placeholder="••••••••"
                required
              />
            </div>
            
            <button
              type="submit"
              className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition duration-200 shadow-lg"
            >
              Anmelden
            </button>
          </form>

          <div className="mt-6 p-4 bg-gray-50 rounded-lg text-sm text-gray-600">
            <p className="font-semibold mb-2">Test-Zugänge:</p>
            <p>User: max@example.com / pass123</p>
            <p>Admin: admin@example.com / admin123</p>
          </div>
        </div>
      </div>
    );
  }

  // Admin View
  if (showAdminView && currentUser.isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-indigo-600 text-white p-6 shadow-lg">
          <div className="max-w-6xl mx-auto flex justify-between items-center">
            <div className="flex items-center gap-3">
              <Settings className="w-8 h-8" />
              <h1 className="text-2xl font-bold">Admin Bereich</h1>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm">Admin: {currentUser.nickname}</span>
              <button
                onClick={() => setShowAdminView(false)}
                className="px-4 py-2 bg-white text-indigo-600 rounded-lg hover:bg-gray-100 transition"
              >
                Zur User-Ansicht
              </button>
              <button onClick={handleLogout} className="p-2 hover:bg-indigo-700 rounded-lg transition">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </header>

        <div className="max-w-6xl mx-auto p-6 space-y-8">
          {/* Spieler verwalten */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
              <Users className="w-6 h-6 text-indigo-600" />
              Spieler verwalten
            </h2>
            <div className="space-y-3">
              {players.filter(p => !p.isAdmin).map(player => (
                <div key={player.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold ${playersStatus[player.id] ? 'bg-green-500' : 'bg-red-500'}`}>
                      {player.nickname[0]}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">{player.nickname}</p>
                      <p className="text-sm text-gray-600">{player.email}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => togglePlayerStatus(player.id)}
                    className={`px-6 py-2 rounded-lg font-semibold transition ${
                      playersStatus[player.id]
                        ? 'bg-red-100 text-red-700 hover:bg-red-200'
                        : 'bg-green-100 text-green-700 hover:bg-green-200'
                    }`}
                  >
                    {playersStatus[player.id] ? 'Blockieren' : 'Aktivieren'}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Event erstellen */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
              <Plus className="w-6 h-6 text-indigo-600" />
              Neues Event erstellen
            </h2>
            <form onSubmit={handleCreateEvent} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Event Titel"
                  value={newEvent.title}
                  onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                  className="px-4 py-3 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                  required
                />
                <input
                  type="text"
                  placeholder="Ort"
                  value={newEvent.location}
                  onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                  className="px-4 py-3 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input
                  type="date"
                  value={newEvent.date}
                  onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                  className="px-4 py-3 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                  required
                />
                <input
                  type="time"
                  placeholder="Von"
                  value={newEvent.timeFrom}
                  onChange={(e) => setNewEvent({ ...newEvent, timeFrom: e.target.value })}
                  className="px-4 py-3 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                  required
                />
                <input
                  type="time"
                  placeholder="Bis"
                  value={newEvent.timeTo}
                  onChange={(e) => setNewEvent({ ...newEvent, timeTo: e.target.value })}
                  className="px-4 py-3 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition"
              >
                Event erstellen
              </button>
            </form>
          </div>

          {/* Definierte Utensilien */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Definierte Utensilien</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {utensils.map(utensil => (
                <div key={utensil.id} className="p-4 border-2 border-indigo-200 rounded-lg text-center">
                  <div className="text-4xl mb-2">{utensil.icon}</div>
                  <p className="font-semibold text-gray-800">{utensil.name}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Events übersicht */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Alle Events</h2>
            <div className="space-y-4">
              {events.map(event => (
                <div key={event.id} className="p-4 border rounded-lg flex justify-between items-center hover:bg-gray-50">
                  <div>
                    <h3 className="font-semibold text-lg">{event.title}</h3>
                    <p className="text-sm text-gray-600">
                      {new Date(event.date).toLocaleDateString('de-DE')} | {event.timeFrom} - {event.timeTo} | {event.location}
                    </p>
                    <p className="text-sm text-indigo-600 mt-1">
                      {countParticipants(event)} Teilnehmer
                    </p>
                  </div>
                  <button
                    onClick={() => handleDeleteEvent(event.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // User View
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-indigo-600 text-white p-6 shadow-lg">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Calendar className="w-8 h-8" />
            <h1 className="text-2xl font-bold">Event Manager</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm">Hallo, {currentUser.nickname}!</span>
            {currentUser.isAdmin && (
              <button
                onClick={() => setShowAdminView(true)}
                className="px-4 py-2 bg-white text-indigo-600 rounded-lg hover:bg-gray-100 transition flex items-center gap-2"
              >
                <Settings className="w-4 h-4" />
                Admin
              </button>
            )}
            <button onClick={handleLogout} className="p-2 hover:bg-indigo-700 rounded-lg transition">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-6 space-y-6">
        {/* Spielerliste */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
            <Users className="w-6 h-6 text-indigo-600" />
            Spieler
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {players.filter(p => !p.isAdmin && playersStatus[p.id]).map(player => (
              <div key={player.id} className="flex items-center gap-3 p-3 border rounded-lg">
                <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold">
                  {player.nickname[0]}
                </div>
                <div>
                  <p className="font-semibold text-sm">{player.nickname}</p>
                  <p className="text-xs text-gray-600">{player.email}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Events */}
        {events.map(event => (
          <div key={event.id} className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-white">
              <h3 className="text-2xl font-bold mb-3">{event.title}</h3>
              <div className="flex flex-wrap gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  {new Date(event.date).toLocaleDateString('de-DE', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  {event.timeFrom} - {event.timeTo}
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {event.location}
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  {countParticipants(event)} Teilnehmer
                </div>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Zusage/Absage */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-3">Deine Antwort:</h4>
                <div className="flex gap-4">
                  <button
                    onClick={() => handleResponse(event.id, 'yes')}
                    className={`flex-1 py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2 ${
                      event.responses[currentUser.id] === 'yes'
                        ? 'bg-green-500 text-white shadow-lg'
                        : 'bg-gray-100 text-gray-700 hover:bg-green-100'
                    }`}
                  >
                    <CheckCircle className="w-5 h-5" />
                    Zusage
                  </button>
                  <button
                    onClick={() => handleResponse(event.id, 'no')}
                    className={`flex-1 py-3 rounded-lg font-semibold transition flex items-center justify-center gap-2 ${
                      event.responses[currentUser.id] === 'no'
                        ? 'bg-red-500 text-white shadow-lg'
                        : 'bg-gray-100 text-gray-700 hover:bg-red-100'
                    }`}
                  >
                    <XCircle className="w-5 h-5" />
                    Absage
                  </button>
                </div>
              </div>

              {/* Utensilien */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-3">Utensilien mitbringen:</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {utensils.map(utensil => {
                    const key = `${event.id}-${utensil.id}`;
                    const bringer = utensilResponses[key];
                    const isBringingIt = bringer === currentUser.id;
                    const bringerName = bringer ? players.find(p => p.id === bringer)?.nickname : null;

                    return (
                      <div key={utensil.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-2xl">{utensil.icon}</span>
                            <span className="font-semibold">{utensil.name}</span>
                          </div>
                        </div>
                        {bringerName && !isBringingIt && (
                          <p className="text-sm text-green-600 mb-2">✓ {bringerName} bringt mit</p>
                        )}
                        <button
                          onClick={() => handleUtensilResponse(event.id, utensil.id, !isBringingIt)}
                          className={`w-full py-2 rounded-lg text-sm font-semibold transition ${
                            isBringingIt
                              ? 'bg-green-500 text-white'
                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                          }`}
                        >
                          {isBringingIt ? '✓ Ich bringe mit' : 'Ich bringe mit'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Gäste */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-indigo-600" />
                  Gäste
                </h4>
                {event.guests && event.guests.length > 0 && (
                  <div className="mb-3 space-y-2">
                    {event.guests.map((guest, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm text-gray-700 bg-gray-50 p-2 rounded">
                        <span>👤</span>
                        <span>{guest.name}</span>
                        <span className="text-xs text-gray-500">(von {guest.addedBy})</span>
                      </div>
                    ))}
                  </div>
                )}
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Gast hinzufügen..."
                    value={newGuest[event.id] || ''}
                    onChange={(e) => setNewGuest({ ...newGuest, [event.id]: e.target.value })}
                    className="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    onClick={() => handleAddGuest(event.id)}
                    className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition font-semibold"
                  >
                    <UserPlus className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Kommentare */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-3">💬 Kommentare</h4>
                {event.comments && event.comments.length > 0 && (
                  <div className="mb-3 space-y-3">
                    {event.comments.map((comment, idx) => (
                      <div key={idx} className="bg-gray-50 p-3 rounded-lg">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-sm text-indigo-600">{comment.author}</span>
                          <span className="text-xs text-gray-500">{comment.timestamp}</span>
                        </div>
                        <p className="text-sm text-gray-700">{comment.text}</p>
                      </div>
                    ))}
                  </div>
                )}
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Kommentar schreiben..."
                    value={newComment[event.id] || ''}
                    onChange={(e) => setNewComment({ ...newComment, [event.id]: e.target.value })}
                    className="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    onClick={() => handleAddComment(event.id)}
                    className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition font-semibold"
                  >
                    Senden
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EventManagerApp;