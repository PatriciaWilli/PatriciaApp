# Event Manager App

Eine moderne Event-Management-Anwendung mit Benutzer- und Administrator-Ansicht, entwickelt mit React und Tailwind CSS.

## 🚀 Features

### UserView (Benutzeransicht)
- ✅ **Login-System** - Email und Passwort-basierte Authentifizierung
- ✅ **Spielerliste** - Übersicht aller aktiven Spieler mit Spitznamen und Email
- ✅ **Event-Übersicht** - Liste aller Events mit:
  - Datum, Uhrzeit (von/bis) und Ort
  - Teilnehmerzahl
- ✅ **Zu-/Absagen** - Grüne Zusage oder rote Absage per Button
- ✅ **Utensilien-Management** - Mitbringen von:
  - ⚽ Ball
  - 🔧 Pumpe
  - 👕 Überzieher
- ✅ **Gäste hinzufügen** - Einladung von Gästen mit Symbol
- ✅ **Kommentarfunktion** - Kommentare mit Zeitstempel und Autor

### AdminView (Administrator-Ansicht)
- ✅ **Spielerverwaltung** - Spieler aktivieren/blockieren
- ✅ **Event-Erstellung** - Neue Events mit allen Details erstellen
- ✅ **Event-Verwaltung** - Events löschen und verwalten
- ✅ **Utensilien-Übersicht** - Anzeige aller definierten Utensilien
- ✅ **Statistiken** - Teilnehmerzahlen pro Event

## 📦 Installation

### Voraussetzungen
- Node.js (Version 16 oder höher)
- npm oder yarn

### Schritt 1: Repository klonen
```bash
git clone https://github.com/[IhrUsername]/event-manager-app.git
cd event-manager-app
```

### Schritt 2: Abhängigkeiten installieren
```bash
npm install
```

### Schritt 3: Anwendung starten
```bash
npm start
```

Die App öffnet sich automatisch unter `http://localhost:3000`

## 🔐 Test-Zugänge

### Benutzer-Account
- **Email:** max@example.com
- **Passwort:** pass123

### Administrator-Account
- **Email:** admin@example.com
- **Passwort:** admin123

## 🛠️ Technologie-Stack

- **React 18** - Frontend-Framework
- **Tailwind CSS** - Styling
- **Lucide React** - Icon-Bibliothek
- **React Hooks** - State Management (useState)

## 📁 Projektstruktur

```
event-manager-app/
├── public/
│   ├── index.html
│   └── manifest.json
├── src/
│   ├── App.jsx
│   ├── index.js
│   └── index.css
├── package.json
├── tailwind.config.js
└── README.md
```

## 🎨 Anpassungen

### Spieler hinzufügen
In `src/App.jsx` können Sie neue Spieler im `players` State hinzufügen:

```javascript
const [players] = useState([
  { id: 1, nickname: 'Max', email: 'max@example.com', password: 'pass123', isActive: true, isAdmin: false },
  // Weitere Spieler hinzufügen...
]);
```

### Utensilien anpassen
Utensilien können im `utensils` State geändert werden:

```javascript
const [utensils] = useState([
  { id: 1, name: 'Ball', icon: '⚽' },
  { id: 2, name: 'Pumpe', icon: '🔧' },
  { id: 3, name: 'Überzieher', icon: '👕' }
]);
```

## 🚀 Deployment

### Build für Production
```bash
npm run build
```

Die optimierten Dateien befinden sich dann im `build/` Ordner.

### Deployment-Optionen
- **Vercel** - `vercel deploy`
- **Netlify** - Drag & Drop des `build/` Ordners
- **GitHub Pages** - `npm run deploy`

## 📝 Lizenz

MIT License - Frei verwendbar für private und kommerzielle Projekte

## 👨‍💻 Entwickelt mit

- Claude Sonnet 4.5
- Workshop-Anforderungen vom 30.10.2025

## 🤝 Beitragen

Pull Requests sind willkommen! Für größere Änderungen öffnen Sie bitte zuerst ein Issue.

## 📧 Kontakt

Bei Fragen oder Anregungen öffnen Sie bitte ein Issue auf GitHub.

---

**Viel Spaß mit der Event Manager App! 🎉**
